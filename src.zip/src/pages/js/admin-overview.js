import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import '../css/admin-overview.css';
import AdminProducts from './admin-products';
import AdminCustomers from './admin-customers';
import AdminOrders from './admin-orders';
import AdminFeedback from './admin-feedback';

const menuItems = [
  'Overview',
  'Statistics',
  'Customers',
  'Products',
  'Feedback',
  'Orders',
  'Store'
];

const AdminOverview = () => {
  const location = useLocation();
  const [activeTab, setActiveTab] = useState('Overview');

  useEffect(() => {
    if (location.state?.tab) {
      setActiveTab(location.state.tab);
    }
  }, [location.state]);

  return (
    <div className="admin-container">
      {/* Sidebar */}
      <aside className="sidebar">
        <h2 className="sidebar-title">DUKAANIFY</h2>
        <nav className="sidebar-menu">
          {menuItems.map(item => (
            <a
              key={item}
              href="#"
              className={`sidebar-link ${activeTab === item ? 'active' : ''}`}
              onClick={() => setActiveTab(item)}
            >
              {item}
            </a>
          ))}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="admin-main">
        {activeTab === 'Products' ? (
          <AdminProducts />
        ) : activeTab === 'Customers' ? (
          <AdminCustomers />
        ) : activeTab === 'Orders' ? (
          <AdminOrders />
        ) : activeTab === 'Feedback' ? (
          <AdminFeedback />
        ) : (
          <>
            <h1>{activeTab}</h1>
            <p>You selected the "{activeTab}" section.</p>
          </>
        )}
      </main>
    </div>
  );
};

export default AdminOverview;
