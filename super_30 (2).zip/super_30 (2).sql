-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2025 at 04:32 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `super_30`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `no_of_orders` int(11) NOT NULL DEFAULT 0 CHECK (`no_of_orders` >= 0),
  `amount_spent` decimal(10,2) NOT NULL DEFAULT 0.00 CHECK (`amount_spent` >= 0),
  `date_joined` date NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `customer_name`, `no_of_orders`, `amount_spent`, `date_joined`, `phone_number`, `email`, `address`, `user_id`) VALUES
(501, 'Alice Smith', 5, 250.75, '2023-01-15', '111-222-3333', 'alice.s@example.com', '123 Oak Ave, Anytown, USA', 1),
(502, 'Bob Johnson', 3, 120.00, '2023-02-20', '222-333-4444', 'bob.j@example.com', '456 Pine St, Anytown, USA', 2),
(503, 'Charlie Brown', 8, 500.50, '2023-03-10', '333-444-5555', 'charlie.b@example.com', '789 Maple Rd, Anytown, USA', 3),
(504, 'Ethan Hunt', 10, 950.00, '2023-05-05', '555-666-7777', 'ethan.h@example.com', '202 Cedar Ln, Anytown, USA', 5),
(505, 'Fiona Glenanne', 1, 35.99, '2023-06-12', '666-777-8888', 'fiona.g@example.com', '303 Birch Ct, Anytown, USA', 6),
(506, 'Harry Potter', 4, 180.15, '2023-08-25', '888-999-0000', 'harry.p@example.com', '505 Spruce Dr, Anytown, USA', 8),
(507, 'Ivy Green', 7, 620.40, '2023-09-01', '999-000-1111', 'ivy.g@example.com', '606 Poplar Pl, Anytown, USA', 9),
(508, 'Jack Black', 9, 710.60, '2023-10-10', '000-111-2222', 'jack.b@example.com', '707 Ash Rd, Anytown, USA', 10);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedback_id` int(11) NOT NULL,
  `review_date` datetime NOT NULL,
  `customer_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL CHECK (`rating` >= 1 and `rating` <= 5),
  `product_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedback_id`, `review_date`, `customer_id`, `rating`, `product_id`, `store_id`) VALUES
(401, '2024-05-01 10:00:00', 501, 5, 1001, 201),
(402, '2024-05-03 11:30:00', 502, 4, 1003, 201),
(403, '2024-05-05 14:00:00', 503, 5, 1005, 202),
(404, '2024-05-07 09:45:00', 504, 3, 1002, 201),
(405, '2024-05-09 16:15:00', 505, 4, 1006, 202),
(406, '2024-05-11 13:00:00', 506, 5, 1008, 205),
(407, '2024-05-13 10:30:00', 507, 4, 1009, 203),
(408, '2024-05-15 17:00:00', 508, 3, 1007, 206),
(409, '2024-05-17 08:00:00', 501, 5, 1010, 201),
(410, '2024-05-19 11:00:00', 502, 4, 1004, 201);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `date_ordered` datetime NOT NULL,
  `total_amount` decimal(10,2) NOT NULL CHECK (`total_amount` >= 0),
  `customer_id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `date_ordered`, `total_amount`, `customer_id`, `status`) VALUES
(301, '2024-01-20 10:30:00', 1200.00, 501, 'Delivered'),
(302, '2024-01-22 14:00:00', 80.00, 502, 'Pending'),
(303, '2024-02-05 11:45:00', 45.00, 503, 'Shipped'),
(304, '2024-02-10 09:15:00', 25.00, 501, 'Delivered'),
(305, '2024-02-15 16:20:00', 155.00, 504, 'Processing'),
(306, '2024-03-01 13:00:00', 110.00, 505, 'Delivered'),
(307, '2024-03-10 10:00:00', 35.99, 506, 'Pending'),
(308, '2024-03-15 17:00:00', 280.00, 507, 'Shipped'),
(309, '2024-03-20 08:30:00', 70.00, 508, 'Delivered'),
(310, '2024-04-01 11:00:00', 799.00, 501, 'Processing');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `order_item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL CHECK (`quantity` > 0),
  `store_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`order_item_id`, `order_id`, `product_id`, `quantity`, `store_id`) VALUES
(601, 301, 1001, 1, 201),
(602, 302, 1003, 1, 201),
(603, 303, 1004, 1, 201),
(604, 304, 1002, 1, 201),
(605, 305, 1008, 1, 205),
(606, 306, 1005, 1, 202),
(607, 307, 1002, 1, 201),
(608, 308, 1007, 1, 206),
(609, 309, 1009, 1, 203),
(610, 310, 1010, 1, 201);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL CHECK (`price` >= 0),
  `stock_quantity` int(11) NOT NULL CHECK (`stock_quantity` >= 0),
  `image_url` varchar(255) DEFAULT NULL,
  `product_category` varchar(255) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `description`, `price`, `stock_quantity`, `image_url`, `product_category`, `store_id`) VALUES
(1001, 'Laptop Pro X', 'High-performance laptop with 16GB RAM and 512GB SSD.', 1200.00, 50, 'https://placehold.co/150x150/FFFFFF/000000?text=Laptop', 'Electronics', 201),
(1002, 'Wireless Mouse', 'Ergonomic wireless mouse with adjustable DPI.', 25.00, 200, 'https://placehold.co/150x150/FFFFFF/000000?text=Mouse', 'Peripherals', 201),
(1003, 'Mechanical Keyboard', 'RGB mechanical keyboard with brown switches.', 80.00, 100, 'https://placehold.co/150x150/FFFFFF/000000?text=Keyboard', 'Peripherals', 201),
(1004, 'USB-C Hub', 'Multi-port USB-C hub with HDMI and card reader.', 45.00, 150, 'https://placehold.co/150x150/FFFFFF/000000?text=USBHub', 'Accessories', 201),
(1005, 'Designer Handbag', 'Premium leather handbag with unique design.', 250.00, 30, 'https://placehold.co/150x150/FFFFFF/000000?text=Handbag', 'Fashion', 202),
(1006, 'Summer Dress', 'Light and airy cotton dress for summer.', 60.00, 80, 'https://placehold.co/150x150/FFFFFF/000000?text=Dress', 'Apparel', 202),
(1007, 'Smart Watch X', 'Fitness tracker with heart rate monitor.', 180.00, 70, 'https://placehold.co/150x150/FFFFFF/000000?text=Watch', 'Wearables', 206),
(1008, 'Running Shoes Pro', 'High-performance running shoes with great cushioning.', 120.00, 45, 'https://placehold.co/150x150/FFFFFF/000000?text=Shoes', 'Footwear', 205),
(1009, 'Cookbook: Italian Classics', 'Collection of classic Italian recipes.', 30.00, 100, 'https://placehold.co/150x150/FFFFFF/000000?text=Book', 'Books', 203),
(1010, 'Smartphone XYZ', 'Latest model smartphone with triple camera.', 799.00, 60, 'https://placehold.co/150x150/FFFFFF/000000?text=Smartphone', 'Electronics', 201);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `store_id` int(11) NOT NULL,
  `store_name` varchar(255) NOT NULL,
  `store_email` varchar(255) DEFAULT NULL,
  `store_address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stores`
--

INSERT INTO `stores` (`store_id`, `store_name`, `store_email`, `store_address`, `created_at`, `updated_at`) VALUES
(201, 'Electronics Hub', 'contact@electronicshub.com', '101 Tech Way, Silicon Valley, CA', '2025-06-10 14:19:45', '2025-06-10 14:19:45'),
(202, 'Fashion Forward', 'info@fashionforward.com', '202 Style Blvd, New York, NY', '2025-06-10 14:19:45', '2025-06-10 14:19:45'),
(203, 'Bookworm Corner', 'hello@bookwormcorner.com', '303 Reading Lane, Oxford, UK', '2025-06-10 14:19:45', '2025-06-10 14:19:45'),
(204, 'Home Essentials', 'support@homeessentials.com', '404 Comfort Dr, Chicago, IL', '2025-06-10 14:19:45', '2025-06-10 14:19:45'),
(205, 'Sporting Goods Pro', 'sales@sportinggoodspro.com', '505 Athletic Ave, Los Angeles, CA', '2025-06-10 14:19:45', '2025-06-10 14:19:45'),
(206, 'Gadget Galaxy', 'help@gadgetgalaxy.com', '606 Innovation Rd, Austin, TX', '2025-06-10 14:19:45', '2025-06-10 14:19:45'),
(207, 'Pet Paradise', 'care@petparadise.com', '707 Animal Path, Denver, CO', '2025-06-10 14:19:45', '2025-06-10 14:19:45'),
(208, 'Healthy Foods Co', 'order@healthyfoodsco.com', '808 Green St, Seattle, WA', '2025-06-10 14:19:45', '2025-06-10 14:19:45'),
(209, 'Art & Craft Supply', 'create@artcraftsupply.com', '909 Palette Pl, Portland, OR', '2025-06-10 14:19:45', '2025-06-10 14:19:45'),
(210, 'Global Market', 'inquiry@globalmarket.com', '110 Trade Centre, Miami, FL', '2025-06-10 14:19:45', '2025-06-10 14:19:45');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `user_type` enum('customer','admin') NOT NULL DEFAULT 'customer',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `store_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `email`, `password_hash`, `user_type`, `created_at`, `updated_at`, `store_id`) VALUES
(1, 'alice.s@example.com', '$2a$10$xyz123abc.hashedpassword.alice', 'customer', '2025-06-10 13:17:24', '2025-06-10 13:17:24', NULL),
(2, 'bob.j@example.com', '$2a$10$xyz123abc.hashedpassword.bob', 'customer', '2025-06-10 13:17:24', '2025-06-10 13:17:24', NULL),
(3, 'charlie.b@example.com', '$2a$10$xyz123abc.hashedpassword.charlie', 'customer', '2025-06-10 13:17:24', '2025-06-10 13:17:24', NULL),
(4, 'contact@electronicshub.com', '$2a$10$xyz123abc.hashedpassword.diana', 'admin', '2025-06-10 13:17:24', '2025-06-10 14:04:16', 201),
(5, 'ethan.h@example.com', '$2a$10$xyz123abc.hashedpassword.ethan', 'customer', '2025-06-10 13:17:24', '2025-06-10 13:17:24', NULL),
(6, 'fiona.g@example.com', '$2a$10$xyz123abc.hashedpassword.fiona', 'customer', '2025-06-10 13:17:24', '2025-06-10 13:17:24', NULL),
(7, 'info@fashionforward.com', '$2a$10$xyz123abc.hashedpassword.grace', 'admin', '2025-06-10 13:17:24', '2025-06-10 14:04:16', 202),
(8, 'harry.p@example.com', '$2a$10$xyz123abc.hashedpassword.harry', 'customer', '2025-06-10 13:17:24', '2025-06-10 13:17:24', NULL),
(9, 'ivy.g@example.com', '$2a$10$xyz123abc.hashedpassword.ivy', 'customer', '2025-06-10 13:17:24', '2025-06-10 13:17:24', NULL),
(10, 'jack.b@example.com', '$2a$10$xyz123abc.hashedpassword.jack', 'customer', '2025-06-10 13:17:24', '2025-06-10 13:17:24', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`),
  ADD UNIQUE KEY `phone_number` (`phone_number`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `fk_feedback_product` (`product_id`),
  ADD KEY `fk_feedback_store` (`store_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD UNIQUE KEY `order_id` (`order_id`,`product_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `fk_order_items_store_id` (`store_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `fk_products_store_id` (`store_id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`store_id`),
  ADD UNIQUE KEY `store_email` (`store_email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `fk_store_id` (`store_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=509;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=411;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=311;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=611;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1011;

--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `store_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=211;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customers`
--
ALTER TABLE `customers`
  ADD CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_feedback_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_feedback_store` FOREIGN KEY (`store_id`) REFERENCES `stores` (`store_id`) ON DELETE SET NULL;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `fk_order_items_store_id` FOREIGN KEY (`store_id`) REFERENCES `stores` (`store_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_products_store_id` FOREIGN KEY (`store_id`) REFERENCES `stores` (`store_id`) ON DELETE SET NULL;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_store_id` FOREIGN KEY (`store_id`) REFERENCES `stores` (`store_id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
